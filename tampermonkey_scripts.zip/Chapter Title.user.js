// ==UserScript==
// @name         Chapter Title
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Fügt Chapter als titel für den Upload von Kapitel hinzu.
// @include      http://proxer.me/*
// @author       Aze
// @match        https://proxer.me/uploadmanga?id=*
// @grant        none
// ==/UserScript==

var type = document.getElementById("uploadmanga_title")
type.value = "Chapter "